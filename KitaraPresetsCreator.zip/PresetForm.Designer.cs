﻿namespace KitaraPresetsCreator
{
    partial class PresetForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Volume");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Master", new System.Windows.Forms.TreeNode[] {
            treeNode1});
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("String #0");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("String #1");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("String #2");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("String #3");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("String #4");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("String #5");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Tuning", new System.Windows.Forms.TreeNode[] {
            treeNode3,
            treeNode4,
            treeNode5,
            treeNode6,
            treeNode7,
            treeNode8});
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Channel #0");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Channel #1");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Channel #2");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Channel #3");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Channel #4");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Channel #5");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("MidiOutChannel", new System.Windows.Forms.TreeNode[] {
            treeNode10,
            treeNode11,
            treeNode12,
            treeNode13,
            treeNode14,
            treeNode15});
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Equalizer");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Reverberation");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Distortion");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Modulation");
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Compression");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("Delay");
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Mixer");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Voice");
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("Control");
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("Preset", new System.Windows.Forms.TreeNode[] {
            treeNode2,
            treeNode9,
            treeNode16,
            treeNode17,
            treeNode18,
            treeNode19,
            treeNode20,
            treeNode21,
            treeNode22,
            treeNode23,
            treeNode24,
            treeNode25});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PresetForm));
            this.contextMenuPresets = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.EditCurrentProperty = new System.Windows.Forms.ToolStripMenuItem();
            this.RemoveCurrentProperty = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddReverb = new System.Windows.Forms.ToolStripMenuItem();
            this.AddCompression = new System.Windows.Forms.ToolStripMenuItem();
            this.AddDistiortion = new System.Windows.Forms.ToolStripMenuItem();
            this.AddDelay = new System.Windows.Forms.ToolStripMenuItem();
            this.AddControl = new System.Windows.Forms.ToolStripMenuItem();
            this.AddModulation = new System.Windows.Forms.ToolStripMenuItem();
            this.AddMixer = new System.Windows.Forms.ToolStripMenuItem();
            this.addControlToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.dataSetPresets = new System.Data.DataSet();
            this.dataTableEqualizer = new System.Data.DataTable();
            this.TableReverberation = new System.Data.DataTable();
            this.tabPresetPage = new System.Windows.Forms.TabPage();
            this.XMLTextBox = new System.Windows.Forms.RichTextBox();
            this.treeViewXML = new System.Windows.Forms.TreeView();
            this.tabPreset = new System.Windows.Forms.TabControl();
            this.contextMenuPresets.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetPresets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTableEqualizer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TableReverberation)).BeginInit();
            this.tabPresetPage.SuspendLayout();
            this.tabPreset.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuPresets
            // 
            this.contextMenuPresets.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EditCurrentProperty,
            this.RemoveCurrentProperty,
            this.addToolStripMenuItem});
            this.contextMenuPresets.Name = "contextMenuPresets";
            this.contextMenuPresets.Size = new System.Drawing.Size(215, 70);
            this.contextMenuPresets.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuPresets_Opening);
            // 
            // EditCurrentProperty
            // 
            this.EditCurrentProperty.Name = "EditCurrentProperty";
            this.EditCurrentProperty.Size = new System.Drawing.Size(214, 22);
            this.EditCurrentProperty.Text = "Edit Current Property...";
            // 
            // RemoveCurrentProperty
            // 
            this.RemoveCurrentProperty.Name = "RemoveCurrentProperty";
            this.RemoveCurrentProperty.Size = new System.Drawing.Size(214, 22);
            this.RemoveCurrentProperty.Text = "Remove Current Property..";
            this.RemoveCurrentProperty.Click += new System.EventHandler(this.RemoveCurrentProperty_Click);
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddReverb,
            this.AddCompression,
            this.AddDistiortion,
            this.AddDelay,
            this.AddControl,
            this.AddModulation,
            this.AddMixer,
            this.addControlToolStripMenuItem2});
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.addToolStripMenuItem.Text = "Add..";
            // 
            // AddReverb
            // 
            this.AddReverb.Name = "AddReverb";
            this.AddReverb.Size = new System.Drawing.Size(181, 22);
            this.AddReverb.Text = "Add Reverberation...";
            this.AddReverb.Click += new System.EventHandler(this.AddReverb_Click);
            // 
            // AddCompression
            // 
            this.AddCompression.Name = "AddCompression";
            this.AddCompression.Size = new System.Drawing.Size(181, 22);
            this.AddCompression.Text = "Add Compression...";
            this.AddCompression.Click += new System.EventHandler(this.addCompressionToolStripMenuItem1_Click);
            // 
            // AddDistiortion
            // 
            this.AddDistiortion.Name = "AddDistiortion";
            this.AddDistiortion.Size = new System.Drawing.Size(181, 22);
            this.AddDistiortion.Text = "Add Distortion...";
            // 
            // AddDelay
            // 
            this.AddDelay.Name = "AddDelay";
            this.AddDelay.Size = new System.Drawing.Size(181, 22);
            this.AddDelay.Text = "Add Delay...";
            // 
            // AddControl
            // 
            this.AddControl.Name = "AddControl";
            this.AddControl.Size = new System.Drawing.Size(181, 22);
            this.AddControl.Text = "Add Control...";
            // 
            // AddModulation
            // 
            this.AddModulation.Name = "AddModulation";
            this.AddModulation.Size = new System.Drawing.Size(181, 22);
            this.AddModulation.Text = "Add Modulation...";
            // 
            // AddMixer
            // 
            this.AddMixer.Name = "AddMixer";
            this.AddMixer.Size = new System.Drawing.Size(181, 22);
            this.AddMixer.Text = "Add Mixer...";
            // 
            // addControlToolStripMenuItem2
            // 
            this.addControlToolStripMenuItem2.Name = "addControlToolStripMenuItem2";
            this.addControlToolStripMenuItem2.Size = new System.Drawing.Size(181, 22);
            this.addControlToolStripMenuItem2.Text = "Add Control...";
            // 
            // dataSetPresets
            // 
            this.dataSetPresets.CaseSensitive = true;
            this.dataSetPresets.DataSetName = "PresetsDataSet";
            this.dataSetPresets.Locale = new System.Globalization.CultureInfo("en");
            this.dataSetPresets.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTableEqualizer,
            this.TableReverberation});
            // 
            // dataTableEqualizer
            // 
            this.dataTableEqualizer.TableName = "TableEqualizer";
            // 
            // TableReverberation
            // 
            this.TableReverberation.TableName = "TableReverberation";
            // 
            // tabPresetPage
            // 
            this.tabPresetPage.Controls.Add(this.XMLTextBox);
            this.tabPresetPage.Controls.Add(this.treeViewXML);
            this.tabPresetPage.Location = new System.Drawing.Point(4, 22);
            this.tabPresetPage.Name = "tabPresetPage";
            this.tabPresetPage.Padding = new System.Windows.Forms.Padding(3);
            this.tabPresetPage.Size = new System.Drawing.Size(797, 425);
            this.tabPresetPage.TabIndex = 0;
            this.tabPresetPage.Text = "Preset";
            this.tabPresetPage.UseVisualStyleBackColor = true;
            // 
            // XMLTextBox
            // 
            this.XMLTextBox.AcceptsTab = true;
            this.XMLTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.XMLTextBox.Enabled = false;
            this.XMLTextBox.Location = new System.Drawing.Point(245, 0);
            this.XMLTextBox.Name = "XMLTextBox";
            this.XMLTextBox.Size = new System.Drawing.Size(549, 425);
            this.XMLTextBox.TabIndex = 1;
            this.XMLTextBox.Text = "";
            // 
            // treeViewXML
            // 
            this.treeViewXML.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.treeViewXML.ContextMenuStrip = this.contextMenuPresets;
            this.treeViewXML.FullRowSelect = true;
            this.treeViewXML.LabelEdit = true;
            this.treeViewXML.Location = new System.Drawing.Point(3, 0);
            this.treeViewXML.Name = "treeViewXML";
            treeNode1.Name = "nodeMasterVolume";
            treeNode1.Tag = "Volume";
            treeNode1.Text = "Volume";
            treeNode2.Name = "nodeMaster";
            treeNode2.Tag = "Master";
            treeNode2.Text = "Master";
            treeNode3.Name = "nodeString0";
            treeNode3.Tag = "t1";
            treeNode3.Text = "String #0";
            treeNode4.Name = "nodeString1";
            treeNode4.Tag = "t2";
            treeNode4.Text = "String #1";
            treeNode5.Name = "nodeString2";
            treeNode5.Tag = "t3";
            treeNode5.Text = "String #2";
            treeNode6.Name = "nodeString3";
            treeNode6.Tag = "t4";
            treeNode6.Text = "String #3";
            treeNode7.Name = "nodeString4";
            treeNode7.Tag = "t5";
            treeNode7.Text = "String #4";
            treeNode8.Name = "nodeString5";
            treeNode8.Tag = "6";
            treeNode8.Text = "String #5";
            treeNode9.Name = "nodeTuning";
            treeNode9.Tag = "Tuning";
            treeNode9.Text = "Tuning";
            treeNode10.Name = "nodeChannel0";
            treeNode10.Tag = "ch1";
            treeNode10.Text = "Channel #0";
            treeNode11.Name = "nodeChannel1";
            treeNode11.Tag = "ch2";
            treeNode11.Text = "Channel #1";
            treeNode12.Name = "nodeChannel2";
            treeNode12.Tag = "ch3";
            treeNode12.Text = "Channel #2";
            treeNode13.Name = "nodeChannel3";
            treeNode13.Tag = "ch4";
            treeNode13.Text = "Channel #3";
            treeNode14.Name = "nodeChannel4";
            treeNode14.Tag = "ch5";
            treeNode14.Text = "Channel #4";
            treeNode15.Name = "nodeChannel5";
            treeNode15.Tag = "ch6";
            treeNode15.Text = "Channel #5";
            treeNode16.Name = "nodeMidiOutChannel";
            treeNode16.Tag = "MidiOutChannel";
            treeNode16.Text = "MidiOutChannel";
            treeNode17.Name = "nodeEqualizer";
            treeNode17.Tag = "Equalizer";
            treeNode17.Text = "Equalizer";
            treeNode18.Name = "nodeReverb";
            treeNode18.Tag = "Reverberation";
            treeNode18.Text = "Reverberation";
            treeNode19.Name = "nodeDistortion";
            treeNode19.Tag = "Distortion";
            treeNode19.Text = "Distortion";
            treeNode20.Name = "nodeModulation";
            treeNode20.Tag = "Modulation";
            treeNode20.Text = "Modulation";
            treeNode21.Name = "nodeCompression";
            treeNode21.Tag = "Compression";
            treeNode21.Text = "Compression";
            treeNode22.Name = "nodeDelay";
            treeNode22.Tag = "Delay";
            treeNode22.Text = "Delay";
            treeNode23.Name = "nodeMixer";
            treeNode23.Tag = "Mixer";
            treeNode23.Text = "Mixer";
            treeNode24.Name = "nodeVoice";
            treeNode24.Tag = "Voice";
            treeNode24.Text = "Voice";
            treeNode25.Name = "nodeControl";
            treeNode25.Tag = "Control";
            treeNode25.Text = "Control";
            treeNode26.Name = "rootPreset";
            treeNode26.Tag = "Preset";
            treeNode26.Text = "Preset";
            this.treeViewXML.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode26});
            this.treeViewXML.ShowNodeToolTips = true;
            this.treeViewXML.Size = new System.Drawing.Size(236, 425);
            this.treeViewXML.TabIndex = 0;
            this.treeViewXML.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewXML_AfterSelect);
            // 
            // tabPreset
            // 
            this.tabPreset.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabPreset.Controls.Add(this.tabPresetPage);
            this.tabPreset.Location = new System.Drawing.Point(-5, 0);
            this.tabPreset.Name = "tabPreset";
            this.tabPreset.SelectedIndex = 0;
            this.tabPreset.Size = new System.Drawing.Size(805, 451);
            this.tabPreset.TabIndex = 0;
            // 
            // PresetForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabPreset);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PresetForm";
            this.Text = "New Preset...";
            this.Load += new System.EventHandler(this.PresetForm_Load);
            this.contextMenuPresets.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataSetPresets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTableEqualizer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TableReverberation)).EndInit();
            this.tabPresetPage.ResumeLayout(false);
            this.tabPreset.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip contextMenuPresets;
        private System.Windows.Forms.ToolStripMenuItem EditCurrentProperty;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AddReverb;
        private System.Windows.Forms.ToolStripMenuItem AddCompression;
        private System.Windows.Forms.ToolStripMenuItem AddDistiortion;
        private System.Windows.Forms.ToolStripMenuItem AddDelay;
        private System.Windows.Forms.ToolStripMenuItem AddControl;
        private System.Windows.Forms.ToolStripMenuItem AddModulation;
        private System.Windows.Forms.ToolStripMenuItem AddMixer;
        private System.Windows.Forms.ToolStripMenuItem addControlToolStripMenuItem2;
        private System.Data.DataSet dataSetPresets;
        private System.Data.DataTable dataTableEqualizer;
        private System.Windows.Forms.ToolStripMenuItem RemoveCurrentProperty;
        private System.Data.DataTable TableReverberation;
        private System.Windows.Forms.TabPage tabPresetPage;
        private System.Windows.Forms.RichTextBox XMLTextBox;
        private System.Windows.Forms.TreeView treeViewXML;
        private System.Windows.Forms.TabControl tabPreset;
    }
}